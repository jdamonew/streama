# Screen Share App

Aplicação React com:

- **TypeScript** em 100% do código (sem `any`)
- **Styled Components** para todo o Design System (tema tipado via `ThemeProvider`)
- **Sass/SCSS** apenas para fundamentos globais estáticos (reset, box-sizing)
- Login por e-mail/senha e login com Google (Firebase Authentication)
- Lista de usuários **ativos**, com transmissão de tela 1-para-N (WebRTC + Firestore como sinalização)
- Modal de configuração da transmissão (superfície + qualidade 5/30/60 FPS)
- Tela cheia, encerramento a qualquer momento e aviso de encerramento pro espectador

## Arquitetura

```
                         DESIGN SYSTEM
                              │
             ┌────────────────┼────────────────┐
             ▼                ▼                ▼
       Components       Design Tokens        Theme
             │                │                │
             └────────────────┼────────────────┘
                              │
                              ▼
                    Styled Components
                              │
                              ▼
                         APPLICATION
                              │
              ┌───────────────┼───────────────┐
              ▼               ▼               ▼
            Pages          Hooks           Components
              │               │               │
              └───────────────┼───────────────┘
                              ▼
                       Business Logic
```

- **`src/design-system/`** — camada 100% Styled Components: tokens (`theme/`), `GlobalStyle.ts` (estilos globais que dependem do tema) e os componentes visuais reutilizáveis (`Button`, `Card`, `Avatar`, `Badge`, `Input`, `Typography`, `Stack`, `Modal`). Nenhum componente aqui usa CSS/SCSS próprio.
- **`src/styles/`** — Sass apenas para fundamentos estáticos que **não** dependem do tema em JS (reset de `box-sizing`, margin/padding, etc). Não compete com o Design System.
- **`src/components/`** — componentes de aplicação (regra de negócio de transmissão/usuários), todos reaproveitando o Design System via Styled Components próprios (`Component.styles.ts`).
- **`src/pages/`** — telas (`Login`, `Dashboard`).
- **`src/hooks/useBroadcast.ts`** — toda a lógica de WebRTC (host 1-para-N + espectador) via Firestore.
- **`src/context/AuthContext.tsx`** — autenticação (login, cadastro, Google, logout).
- **`src/types/firestore.ts`** — tipos de domínio compartilhados (documentos do Firestore, estados de UI).

## Padrão de cada componente

```
ComponentName/
├── ComponentName.tsx         # lógica + JSX, tipado
├── ComponentName.styles.ts   # Styled Components (nunca .css/.scss)
└── index.ts                  # barrel export
```

Essa convenção é seguida tanto no Design System quanto nos componentes de aplicação, para manter uma única estratégia de estilização no projeto inteiro.

## 1. Instalar dependências

```bash
npm install
```

## 2. Criar e configurar o projeto Firebase

1. Acesse https://console.firebase.google.com e crie um projeto novo.
2. Vá em **Build > Authentication > Sign-in method** e ative os provedores:
   - **E-mail/senha**
   - **Google**
3. Vá em **Build > Firestore Database** e crie o banco (pode começar em modo de teste).
4. Vá em **Configurações do projeto > Seus apps > Web (</>)** e registre um app web. Copie as credenciais geradas.
5. Copie o arquivo `.env.example` para `.env` e preencha:

```bash
cp .env.example .env
```

```
VITE_FIREBASE_API_KEY=xxxx
VITE_FIREBASE_AUTH_DOMAIN=xxxx.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=xxxx
VITE_FIREBASE_STORAGE_BUCKET=xxxx.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=xxxx
VITE_FIREBASE_APP_ID=xxxx
```

## 3. Regras do Firestore

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }

    match /broadcasts/{broadcastId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null && request.resource.data.hostId == request.auth.uid;
      allow update: if request.auth != null; // simplificado para o exemplo

      match /viewers/{viewerId} {
        allow read, write: if request.auth != null;

        match /hostCandidates/{candidateId} {
          allow read, write: if request.auth != null;
        }
        match /viewerCandidates/{candidateId} {
          allow read, write: if request.auth != null;
        }
      }
    }
  }
}
```

## 4. Rodar o projeto

```bash
npm run dev        # ambiente de desenvolvimento
npm run typecheck  # valida o TypeScript sem gerar build (tsc --noEmit)
npm run build      # tsc + build de produção via Vite
```

Abra o endereço mostrado no terminal em duas abas/navegadores diferentes, com dois usuários logados, para testar a transmissão de tela.

## Limitações e próximos passos sugeridos

- **TURN server**: os STUN públicos do Google (`src/firebase.ts`) resolvem a maioria dos casos; redes corporativas com NAT restritivo podem precisar de um TURN próprio.
- **Presença online**: se o usuário fechar a aba abruptamente, pode continuar aparecendo como online/ao vivo até novo login. Para presença robusta, considere Firebase **Realtime Database** com `onDisconnect()`.
- **Escalabilidade de espectadores**: fan-out via WebRTC puro (uma `RTCPeerConnection` por espectador). Para audiências grandes, considere um SFU dedicado (mediasoup, LiveKit, Janus).
